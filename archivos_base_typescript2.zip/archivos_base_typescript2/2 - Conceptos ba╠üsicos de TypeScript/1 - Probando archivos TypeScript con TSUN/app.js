var Saludo = (function () {
    function Saludo() {
        console.log("Hola Mundo");
    }
    return Saludo;
}());
var saludo = new Saludo();
