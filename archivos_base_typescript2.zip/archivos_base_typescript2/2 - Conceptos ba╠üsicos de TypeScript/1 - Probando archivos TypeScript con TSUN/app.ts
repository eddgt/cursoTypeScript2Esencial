class Saludo {
    constructor() {
        console.log("Hola Mundo");
    }
}

var saludo = new Saludo();