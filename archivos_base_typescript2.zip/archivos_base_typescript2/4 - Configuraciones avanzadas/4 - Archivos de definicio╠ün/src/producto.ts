export class Producto {
    constructor() {
        console.log("Soy un producto");
    }
} 

export const products = [
    { id: 1, name: "Pantalla" },
    { id: 2, name: "Teléfono" },
    { id: 3, name: "Audífonos" }
];