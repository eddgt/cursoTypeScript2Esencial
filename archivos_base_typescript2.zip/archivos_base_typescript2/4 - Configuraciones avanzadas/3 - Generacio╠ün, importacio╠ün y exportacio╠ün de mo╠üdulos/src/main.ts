import { Producto, datos } from './producto'

new Producto();

class App {
    constructor() {
        console.log("Esta es una nueva app");
    }
}

new App();