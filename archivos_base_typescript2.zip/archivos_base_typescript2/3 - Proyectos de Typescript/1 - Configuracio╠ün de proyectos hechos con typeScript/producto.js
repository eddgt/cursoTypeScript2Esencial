"use strict";
var Producto = (function () {
    function Producto() {
    }
    return Producto;
}());
