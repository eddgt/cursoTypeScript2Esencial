export class Producto {
    constructor() {
        console.log("Soy un producto");
    }
}