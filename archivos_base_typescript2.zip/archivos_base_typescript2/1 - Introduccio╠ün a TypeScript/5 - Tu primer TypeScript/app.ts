console.log("Hola Mundo");

alert("Hola Mundo");