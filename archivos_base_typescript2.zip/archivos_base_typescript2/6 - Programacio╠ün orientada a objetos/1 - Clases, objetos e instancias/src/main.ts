import { Producto } from './producto'

let producto = new Producto("123");

producto.garantia = true;

class App {

    constructor() {
        console.log("Esta es una nueva app");
    }
}


new App();

