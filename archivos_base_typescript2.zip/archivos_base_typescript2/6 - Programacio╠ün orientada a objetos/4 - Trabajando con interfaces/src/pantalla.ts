export interface Pantalla {
    pulgadas: number;

    encender(): boolean;
    apagar(): boolean;
}