import { Producto, products } from './producto'

new Producto("123");

class App {

    constructor() {
        console.log("Esta es una nueva app");
    }
}


new App();

